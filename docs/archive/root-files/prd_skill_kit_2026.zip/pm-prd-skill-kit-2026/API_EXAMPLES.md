# API 示例

## 1. 调用某个 Skill
```http
POST /skills/prd-draft-writer/run
Content-Type: application/json
```

```json
{
  "requirement_brief": {
    "project_id": "prd-2026-001",
    "title": "商家财务流水批量导出",
    "request_type": "new_feature",
    "problem_statement": "月底对账效率低",
    "target_users": ["商家财务", "客服"],
    "business_goal": "降低人工支持成本",
    "urgency": "p1",
    "facts": ["存在月底对账低效问题"],
    "assumptions": ["导出能力可能改善效率"],
    "open_questions": ["导出字段范围是什么？"]
  },
  "goals": ["提升对账效率", "降低客服工单"],
  "scope": {
    "mvp": ["按日期范围导出 CSV", "管理员权限控制"],
    "out": ["移动端支持"]
  },
  "design_context": "B端后台财务中心新增导出入口"
}
```

## 2. 响应示例
```json
{
  "facts": ["本期核心能力是财务流水导出"],
  "assumptions": ["CSV 可以覆盖第一期主要场景"],
  "open_questions": ["是否需要异步导出"],
  "artifact": {
    "project_id": "prd-2026-001",
    "title": "商家财务流水批量导出",
    "status": "draft"
  },
  "markdown": "# 商家财务流水批量导出\n..."
}
```

## 3. 保存项目状态
```http
POST /projects/prd-2026-001/artifacts/prd_document
```

## 4. 获取项目状态
```http
GET /projects/prd-2026-001/state
```
