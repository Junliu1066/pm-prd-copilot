# 给 Codex 的开发说明

## 目标
把 PM 的 PRD 工作拆成一组可组合的 Skill，每个 Skill 都有稳定输入、稳定输出和可验证的质量标准。

## 推荐技术栈
### 方案 A：Python
- FastAPI
- Pydantic / jsonschema
- PostgreSQL / SQLite
- OpenAI Responses API or equivalent
- Markdown renderer
- Langfuse / OpenTelemetry（可选）

### 方案 B：TypeScript
- Next.js / Node.js
- Zod
- Prisma
- Postgres
- OpenAI SDK or equivalent

## 最佳实践
1. 每个 Skill 单独模块化
2. prompt 与 schema 分离存储
3. 任何输出都先过 schema validation
4. 生成 markdown 时，同时返回 structured JSON
5. 所有高风险字段都要求显式来源或标注 assumption
6. 记录 prompt version / model version / artifact version

## 目录建议
```text
src/
  orchestrator/
  skills/
    requirement-intake-normalizer/
    prioritization-scorer/
    prd-draft-writer/
    user-story-ac-generator/
    edge-case-risk-checker/
    tracking-plan-designer/
    review-comment-merger/
    launch-retro-copilot/
  schemas/
  prompts/
  tests/
```

## API 建议
- POST /skills/:skill_id/run
- POST /projects
- GET /projects/:project_id/state
- POST /projects/:project_id/artifacts/:artifact_type
- POST /projects/:project_id/reviews/merge

## 质量门槛
- schema 校验通过
- 必填字段不为空
- facts / assumptions / open_questions 三分法齐全
- acceptance criteria 必须是可测试句子
- 所有指标都必须包含口径说明
- review merge 不能静默删除冲突意见
