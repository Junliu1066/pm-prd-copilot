# PM PRD Skill Kit 2026

这是一个给 Codex / 开发团队使用的产品规格包，用来搭建一套围绕 PRD 生命周期的 Skill 系统。

## 包含内容
- 产品经理 PRD 模板
- 技能清单（8 个核心 Skill）
- 每个 Skill 的 system prompt
- input/output schema
- spec 文档
- eval case
- 编排与状态模型
- Codex 开发建议

## 推荐落地方式
- 前端：聊天式界面 + 表单式补充输入
- 后端：Skill Router / Orchestrator
- 存储：Markdown + JSON 双写
- 校验：JSON Schema + 单元测试 + 评审 checklist

## 最小可上线版本（MVP）
先做 5 个：
1. requirement-intake-normalizer
2. prd-draft-writer
3. user-story-ac-generator
4. edge-case-risk-checker
5. tracking-plan-designer

## 成功标准
- PM 不再从空白页写 PRD
- 生成结果可直接进入评审
- 研发/测试/数据能读懂且可执行
- 生成内容至少 70% 可直接复用，剩余由 PM 微调
