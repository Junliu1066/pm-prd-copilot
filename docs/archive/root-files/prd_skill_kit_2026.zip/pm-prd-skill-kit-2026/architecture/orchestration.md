# Skill 编排建议

## 目标
不要把系统做成一个“万能 PRD 大模型”。建议做成一个 **Orchestrator + 8 个原子 Skill** 的结构。

## 推荐链路
1. requirement-intake-normalizer
2. prioritization-scorer
3. prd-draft-writer
4. user-story-ac-generator
5. edge-case-risk-checker
6. tracking-plan-designer
7. review-comment-merger
8. launch-retro-copilot

## 状态对象
建议系统围绕一个 `project_state` 运行，至少包含：
- project_id
- project_title
- requirement_brief
- priority_assessment
- prd_document
- story_pack
- risk_report
- tracking_plan
- review_comments
- launch_plan
- retro_summary
- version_history

## Orchestrator 行为
- 识别用户当前处于哪个阶段
- 判断需要调用哪个 Skill
- 读取上一步输出作为上下文
- 做 schema 校验
- 输出 markdown + structured json 双份结果

## 推荐规则
- 每个 Skill 只做一类决策
- 每个 Skill 输出都带 `facts` / `assumptions` / `open_questions`
- 每个 Skill 都必须输出 machine-readable JSON
- 人工修改后的结果优先于模型自动生成结果
