# Orchestrator 伪代码

```python
def run_skill(skill_id: str, payload: dict, project_state: dict) -> dict:
    skill = registry.get(skill_id)
    validated_input = validate_json(payload, skill.input_schema)

    context = collect_context(skill_id=skill_id, project_state=project_state)
    prompt = load_system_prompt(skill_id)
    result = call_llm(
        system_prompt=prompt,
        user_payload=validated_input,
        context=context
    )

    validated_output = validate_json(result, skill.output_schema)
    updated_state = merge_artifact(project_state, skill_id, validated_output)

    save_artifact(project_id=project_state["project_id"], skill_id=skill_id, output=validated_output)
    save_project_state(updated_state)

    return {
        "skill_id": skill_id,
        "artifact": validated_output,
        "project_state": updated_state
    }
```

## Router 逻辑
- 如果用户输入的是原始需求 → 调 `requirement-intake-normalizer`
- 如果用户说“帮我写 PRD” → 先检查是否有 requirement_brief，没有就先生成 brief
- 如果用户说“拆 stories” → 调 `user-story-ac-generator`
- 如果用户说“看看有没有遗漏” → 调 `edge-case-risk-checker`
- 如果用户说“补埋点” → 调 `tracking-plan-designer`
- 如果用户贴了很多评审意见 → 调 `review-comment-merger`
- 如果用户说“快上线了” → 调 `launch-retro-copilot`
```
