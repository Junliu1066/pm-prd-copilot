# 状态模型建议

## project_state
```json
{
  "project_id": "prd-2026-001",
  "project_title": "示例项目",
  "phase": "draft",
  "artifacts": {
    "requirement_brief": {},
    "priority_assessment": {},
    "prd_document": {},
    "story_pack": [],
    "risk_report": {},
    "tracking_plan": {},
    "review_comments": [],
    "launch_plan": {},
    "retro_summary": {}
  },
  "links": {
    "figma": "",
    "jira_epic": "",
    "dashboard": ""
  },
  "version_history": []
}
```

## 存储建议
- 文本主存储：Markdown / Database text field
- 结构化主存储：JSON column / document store
- 检索来源：会议纪要、客服工单、数据分析、历史 PRD、设计稿说明
- 版本控制：Git 或 docs revision

## 核心原则
- Markdown 面向人读
- JSON 面向程序流转
- 不允许只生成 markdown 而没有结构化对象
