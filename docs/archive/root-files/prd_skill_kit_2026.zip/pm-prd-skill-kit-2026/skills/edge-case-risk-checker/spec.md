# 边界与风险检查 Skill

- Skill ID: `edge-case-risk-checker`
- 优先级: P0
- 目标: 扫描 PRD 中遗漏的异常、权限、兼容、风控、合规、性能等风险点。

## 适用场景
- PRD 评审前
- 测试补场景前
- 上线前风险自查

## 必填输入
- `prd_document`: PRD JSON 或 markdown
- `product_type`: B端/SaaS/电商/内容/金融等
- `platforms`: web/app/h5/admin

## 选填输入
- `roles`: 角色与权限模型
- `compliance_flags`: 是否涉及隐私/审计/账务

## 输出
- `risk_report`: 遗漏风险清单
- `edge_case_matrix`: 边界条件矩阵
- `must_fix_before_review`: 评审前必须补齐项

## 处理流程
1. 扫描流程和规则
2. 按异常/权限/状态/兼容/性能/数据一致性分类检查
3. 输出遗漏项
4. 按高中低风险排序

## Guardrails
- 风险结论要说明依据
- 涉及法规时只提示，不自动给出法律判断
- 高风险项不能静默吞掉

## 非目标
- 不代替安全/法务审查
- 不代替完整测试计划

## 接口建议
- input schema: `schemas/common/prd_document.schema.json`
- output schema: `none`

## 质量验收标准
- 输出必须通过 schema 校验（如果存在 schema）
- 必须显示 `facts / assumptions / open_questions` 或等价字段
- 不得把缺失信息自动补造成事实
- 输出要能直接给 PM 继续使用，而不是只有空泛建议

## Eval Case
### 检查导出功能风险
- 示例输入：财务流水导出
- 验收检查：
  - 能提醒权限、导出上限、超时、脱敏、审计日志
