# 上线与复盘 Skill

- Skill ID: `launch-retro-copilot`
- 优先级: P2
- 目标: 生成上线检查表、go/no-go 会议材料、上线后观察表和复盘初稿。

## 适用场景
- 临近上线
- 灰度前
- 上线后一周内复盘

## 必填输入
- `prd_document`: 当前 PRD
- `release_scope`: 本次上线范围
- `monitoring_inputs`: 监控指标和回滚条件

## 选填输入
- `incident_log`: 上线异常
- `post_metrics`: 上线后数据

## 输出
- `launch_checklist`: 上线清单
- `go_no_go_matrix`: 放行判断矩阵
- `release_note_draft`: 发布说明
- `retro_summary`: 复盘初稿

## 处理流程
1. 梳理上线条件
2. 生成灰度/回滚清单
3. 产出观察指标
4. 汇总上线结果
5. 生成复盘摘要

## Guardrails
- 没有 post_metrics 时不能假装复盘完成
- go/no-go 只做辅助建议
- 必须输出已知风险

## 非目标
- 不自动执行发布
- 不替代事故响应

## 接口建议
- input schema: `schemas/common/prd_document.schema.json`
- output schema: `none`

## 质量验收标准
- 输出必须通过 schema 校验（如果存在 schema）
- 必须显示 `facts / assumptions / open_questions` 或等价字段
- 不得把缺失信息自动补造成事实
- 输出要能直接给 PM 继续使用，而不是只有空泛建议

## Eval Case
### 上线前检查
- 示例输入：导出功能灰度上线
- 验收检查：
  - 有灰度策略、回滚条件、客服通知、埋点检查
