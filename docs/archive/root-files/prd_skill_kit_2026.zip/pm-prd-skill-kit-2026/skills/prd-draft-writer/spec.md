# PRD 初稿生成 Skill

- Skill ID: `prd-draft-writer`
- 优先级: P0
- 目标: 基于 requirement brief、目标、范围、设计约束，生成一份现代结构的 PRD 初稿。

## 适用场景
- PM 已经完成问题定义
- 要从空白页进入 PRD 草稿
- 要把简报转成可评审文档

## 必填输入
- `requirement_brief`: 结构化需求简报
- `goals`: 目标与非目标
- `scope`: In/Out/MVP
- `design_context`: 流程、页面、链接

## 选填输入
- `technical_constraints`: 技术约束
- `metrics`: 目标指标
- `dependency_notes`: 外部依赖

## 输出
- `prd_document`: 结构化 PRD JSON
- `prd_markdown`: 完整 markdown
- `missing_sections`: 还缺哪些信息

## 处理流程
1. 组装主文档结构
2. 填充背景/目标/场景/范围
3. 生成详细需求框架
4. 列出开放问题
5. 输出 markdown + JSON 双份

## Guardrails
- 不应编造具体接口细节
- 不应将未确认信息写成确定规则
- 必须显式输出 open questions

## 非目标
- 不替代设计稿
- 不输出最终技术方案

## 接口建议
- input schema: `schemas/common/requirement_brief.schema.json`
- output schema: `schemas/common/prd_document.schema.json`

## 质量验收标准
- 输出必须通过 schema 校验（如果存在 schema）
- 必须显示 `facts / assumptions / open_questions` 或等价字段
- 不得把缺失信息自动补造成事实
- 输出要能直接给 PM 继续使用，而不是只有空泛建议

## Eval Case
### 从 requirement brief 到 PRD
- 示例输入：商家批量导出财务流水需求
- 验收检查：
  - PRD 有 background/goals/scope/requirements/open_questions
  - 有 out of scope
  - 有上线与指标章节
