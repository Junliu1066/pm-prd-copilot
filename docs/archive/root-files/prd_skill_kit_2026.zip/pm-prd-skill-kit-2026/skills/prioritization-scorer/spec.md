# 优先级评估 Skill

- Skill ID: `prioritization-scorer`
- 优先级: P1
- 目标: 根据 RICE / ICE / MoSCoW 等方法给出可解释的优先级建议。

## 适用场景
- 需求池排序
- 季度规划前的打分
- 评审时需要解释为什么先做这个

## 必填输入
- `requirement_brief`: 结构化需求简报
- `scoring_method`: RICE/ICE/MoSCoW
- `effort_estimate`: 人天或粗估复杂度

## 选填输入
- `reach`: 覆盖人数/订单/商家数
- `impact`: 高/中/低或 1-5
- `confidence`: 0-1 or 0-100%
- `strategic_alignment`: 与 OKR/季度重点的关联

## 输出
- `priority_assessment`: 评分结果
- `recommended_bucket`: P0/P1/P2/P3
- `explanation`: 为什么是这个优先级
- `risk_notes`: 评分不确定项

## 处理流程
1. 读取 requirement_brief
2. 收集打分字段
3. 根据选定框架计算或归类
4. 输出解释性建议
5. 标出低置信度字段

## Guardrails
- 没有数据就不能假造 reach/impact 数值
- 必须暴露不确定性
- 评分只能辅助，不能替代业务拍板

## 非目标
- 不做组织层面的资源决策
- 不自动修改 roadmap

## 接口建议
- input schema: `schemas/common/requirement_brief.schema.json`
- output schema: `none`

## 质量验收标准
- 输出必须通过 schema 校验（如果存在 schema）
- 必须显示 `facts / assumptions / open_questions` 或等价字段
- 不得把缺失信息自动补造成事实
- 输出要能直接给 PM 继续使用，而不是只有空泛建议

## Eval Case
### RICE 打分
- 示例输入：一个影响 30% 商家发货效率的需求，开发成本高
- 验收检查：
  - 会给出高业务价值但高成本提醒
  - 会要求补充 baseline 和 effort
