# 需求 Intake 结构化 Skill

- Skill ID: `requirement-intake-normalizer`
- 优先级: P0
- 目标: 把聊天记录、会议纪要、老板口头需求、工单原文，整理成结构化需求简报。

## 适用场景
- 用户输入原始需求但结构混乱
- 需要从多个来源整理成统一需求卡
- PM 还没进入正式 PRD 撰写阶段

## 必填输入
- `raw_input_text`: 原始需求文本
- `request_channel`: 来源渠道，如 meeting/chat/email/ticket
- `project_context`: 业务线、产品、模块

## 选填输入
- `attachments_summary`: 附件摘要
- `desired_launch_date`: 期望上线时间
- `existing_evidence`: 已有数据/用户反馈/截图

## 输出
- `requirement_brief`: 结构化需求简报 JSON
- `clarification_questions`: 待补充问题列表
- `markdown_summary`: 可直接贴进文档的一页摘要

## 处理流程
1. 抽取事实、假设、问题
2. 识别需求类型
3. 生成标准问题陈述
4. 列出关键缺失信息
5. 建议初步优先级

## Guardrails
- 不能把缺失信息伪造成事实
- 必须区分事实/假设/待确认
- 没有证据时只能说 unknown

## 非目标
- 不负责最终优先级拍板
- 不直接输出完整 PRD

## 接口建议
- input schema: `schemas/common/requirement_brief.schema.json`
- output schema: `schemas/common/requirement_brief.schema.json`

## 质量验收标准
- 输出必须通过 schema 校验（如果存在 schema）
- 必须显示 `facts / assumptions / open_questions` 或等价字段
- 不得把缺失信息自动补造成事实
- 输出要能直接给 PM 继续使用，而不是只有空泛建议

## Eval Case
### 群聊碎片需求归一化
- 示例输入：销售说有大客户要批量导出财务流水，不然月底对账特别慢，客服也老被追着要表。
- 验收检查：
  - 能识别角色为销售/财务/客服
  - 能抽出核心问题是对账效率低
  - 能提出需要确认导出字段、数据范围、权限
