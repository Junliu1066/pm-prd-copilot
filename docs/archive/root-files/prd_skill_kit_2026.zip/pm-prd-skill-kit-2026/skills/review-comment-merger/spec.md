# 评审意见整合 Skill

- Skill ID: `review-comment-merger`
- 优先级: P1
- 目标: 把多角色评审意见结构化，给出冲突点、采纳建议和 PRD 修订清单。

## 适用场景
- 评审会后
- 多人评论 PRD 后
- 需要整理 must-fix / should-discuss 项

## 必填输入
- `prd_document`: 当前 PRD
- `review_comments`: 评审意见数组

## 选填输入
- `decision_principles`: 优先级原则/目标原则
- `meeting_notes`: 会议信息

## 输出
- `merged_review_report`: 整合结果
- `conflict_matrix`: 冲突意见表
- `revision_todo`: 修订任务
- `updated_prd_draft`: 更新版草稿

## 处理流程
1. 收集评论
2. 归类 must-fix / should-discuss / nice-to-have / out-of-scope
3. 识别互相冲突的意见
4. 给出建议处理方式
5. 生成修订清单

## Guardrails
- 不能静默删除分歧
- 必须保留来源和 reviewer role
- 不能伪造会议结论

## 非目标
- 不直接替代 PM 做最终拍板
- 不修改事实证据

## 接口建议
- input schema: `schemas/common/review_comment.schema.json`
- output schema: `none`

## 质量验收标准
- 输出必须通过 schema 校验（如果存在 schema）
- 必须显示 `facts / assumptions / open_questions` 或等价字段
- 不得把缺失信息自动补造成事实
- 输出要能直接给 PM 继续使用，而不是只有空泛建议

## Eval Case
### 整合设计、研发、数据三方意见
- 示例输入：三方评论同一个导出需求
- 验收检查：
  - 能识别冲突点
  - 能生成 must-fix 清单
  - 保留意见来源
