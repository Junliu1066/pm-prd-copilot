# 埋点与指标设计 Skill

- Skill ID: `tracking-plan-designer`
- 优先级: P0
- 目标: 从 PRD 的目标和用户流程中，生成指标体系、事件埋点、属性和验证清单。

## 适用场景
- PRD 进入评审或研发前
- 要补数据方案
- 上线前做埋点联调

## 必填输入
- `prd_document`: PRD JSON 或 markdown
- `business_goals`: 核心指标目标
- `existing_taxonomy`: 已有埋点命名规范

## 选填输入
- `dashboard_constraints`: 看板限制
- `owner_mapping`: 数据 owner

## 输出
- `tracking_plan`: 埋点方案
- `metric_tree`: 指标树
- `qa_checklist`: 埋点验证清单

## 处理流程
1. 识别关键转化节点
2. 定义 metric tree
3. 生成 event + property
4. 关联指标归属
5. 输出 QA checklist

## Guardrails
- 事件必须能映射到目标
- 避免只输出 vanity metrics
- 属性名称要遵循命名规范

## 非目标
- 不直接建 BI 看板
- 不替代数据仓库建模

## 接口建议
- input schema: `schemas/common/prd_document.schema.json`
- output schema: `schemas/common/tracking_plan.schema.json`

## 质量验收标准
- 输出必须通过 schema 校验（如果存在 schema）
- 必须显示 `facts / assumptions / open_questions` 或等价字段
- 不得把缺失信息自动补造成事实
- 输出要能直接给 PM 继续使用，而不是只有空泛建议

## Eval Case
### 埋点方案生成
- 示例输入：新增财务流水导出能力
- 验收检查：
  - 有 export_click/export_success/export_fail 等事件
  - 有关联指标和属性
