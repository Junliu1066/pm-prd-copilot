# 用户故事与验收标准 Skill

- Skill ID: `user-story-ac-generator`
- 优先级: P0
- 目标: 把 PRD 中的功能需求拆成用户故事、验收标准和边界测试点。

## 适用场景
- PRD 已经成型，需要拆工单
- 测试需要验收口径
- 研发需要 story 粒度的输入

## 必填输入
- `prd_document`: PRD JSON 或 markdown
- `feature_scope`: 需要拆解的模块

## 选填输入
- `roles`: 角色列表
- `definition_of_done`: 团队完成标准

## 输出
- `story_pack`: 用户故事数组
- `acceptance_test_points`: 验收点
- `jira_ready_items`: 适合建工单的文本

## 处理流程
1. 识别角色、场景、价值
2. 生成 story statement
3. 输出 testable acceptance criteria
4. 补充 edge cases
5. 给出优先级和依赖

## Guardrails
- 验收标准必须可测试
- 不要把实现方案写成验收标准
- 至少覆盖正常路径和关键异常路径

## 非目标
- 不负责排期
- 不生成代码任务细节

## 接口建议
- input schema: `schemas/common/prd_document.schema.json`
- output schema: `schemas/common/user_story.schema.json`

## 质量验收标准
- 输出必须通过 schema 校验（如果存在 schema）
- 必须显示 `facts / assumptions / open_questions` 或等价字段
- 不得把缺失信息自动补造成事实
- 输出要能直接给 PM 继续使用，而不是只有空泛建议

## Eval Case
### 生成用户故事
- 示例输入：管理员可导出指定日期范围的财务流水
- 验收检查：
  - 故事包含 persona/need/benefit
  - 验收标准覆盖权限、日期范围、导出成功与失败
