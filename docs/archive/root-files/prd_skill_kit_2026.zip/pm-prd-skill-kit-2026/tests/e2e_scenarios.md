# 端到端测试场景

## 场景 1：B 端管理后台导出需求
- 原始输入：销售转述的大客户诉求 + 客服反馈 + 一张截图
- 期望链路：
  1. requirement-intake-normalizer 输出结构化简报
  2. prioritization-scorer 给出 P1 / P2 建议
  3. prd-draft-writer 生成 PRD 初稿
  4. user-story-ac-generator 生成 4~8 条 story
  5. edge-case-risk-checker 补齐权限、超时、脱敏、审计
  6. tracking-plan-designer 生成 export 事件和成功率指标

## 场景 2：支付流程转化优化
- 原始输入：漏斗数据 + 用户录屏 + 竞品对比
- 关键检查：
  - 是否区分事实和假设
  - 是否给出护栏指标
  - 是否把范围切成 MVP / V1

## 场景 3：合规类权限改造
- 原始输入：法务要求 + 审计要求 + 现有系统说明
- 关键检查：
  - 风险 Skill 是否提示“需要法务最终确认”
  - Launch Skill 是否要求灰度和回滚
