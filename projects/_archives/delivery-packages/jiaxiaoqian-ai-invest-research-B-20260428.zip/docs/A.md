# A

## Product Summary

Jiaxiaoqian Research is an AI-assisted investment research workspace for active A-share research users. It helps users discover market events, understand related themes, inspect related stocks, and follow important updates.

## MVP Scope

- High-frequency event tracking.
- Event detail page.
- Theme center.
- Market review.
- Stock detail page.
- AI research assistant.
- Watchlist alerts.
- Source citations.
- Risk notes.

## Out of Scope

- Real trading.
- Buy or sell instructions.
- Target prices.
- Position sizing advice.
- Guaranteed returns.
- Full redistribution of unauthorized research reports.

## Required Product Inputs

- Functional flow.
- Wireframe notes.
- AI plan.
- Acceptance criteria.
- Tracking and risk metrics.
