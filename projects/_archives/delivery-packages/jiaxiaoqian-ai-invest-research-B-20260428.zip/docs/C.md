# C

## MVP Release Plan

Delivery uses four top-level stages:

1. Stage 1: MVP core loop.
2. Stage 2: efficiency, quality, and retention.
3. Stage 3: operations, permissions, and scale.
4. Final Stage: stable release and long-term evolution.

## Stage 1 Goal

Complete the minimum loop: event discovery -> event detail -> theme / stock -> stock research -> watchlist alert.

## Stage 2 Goal

Improve stock detail quality, AI feedback, watchlist alerts, and operational dashboards.

## Stage 3 Goal

Improve admin operations, data governance, permissions, and scale readiness.

## Final Stage Goal

Complete beta release, review real usage data, and decide V1 scope.
