# D

## Tracking And Acceptance

## Core Metrics

- Event detail click-through.
- Stock research session count.
- Watchlist conversion.
- AI generation success rate.
- Citation coverage.
- Safety block count.
- Data freshness.

## Acceptance Requirements

- Core path can be completed by an allowlisted user.
- Key AI output includes citations, confidence, risk notes, and fallback behavior.
- Important data includes source and update time.
- Watchlist and notification flows work.
- Safety-sensitive content is blocked or sent to review.
