# E

## Functional Flow

```mermaid
flowchart TD
  A["User opens workspace"] --> B["High-frequency event tracking"]
  B --> C["Event detail"]
  C --> D["Related theme"]
  C --> E["Related stock"]
  D --> E
  E --> F["AI research insight"]
  E --> G["Watchlist"]
  G --> H["Notification"]
```

## AI Review Flow

```mermaid
flowchart TD
  A["AI generation request"] --> B["Retrieve sources"]
  B --> C["Filter low-quality or unauthorized sources"]
  C --> D["Generate structured output"]
  D --> E["Citation check"]
  E --> F["Safety check"]
  F --> G{"Pass?"}
  G -->|Yes| H["Publish"]
  G -->|No| I["Review or block"]
```
