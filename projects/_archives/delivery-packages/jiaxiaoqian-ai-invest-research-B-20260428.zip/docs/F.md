# F

## Wireframe Notes

## Main Workspace

- Top navigation.
- Search.
- Main research panel.
- Right-side watchlist and quick links.
- Loading, empty, error, stale, permission, and safety-blocked states.

## Key Pages

- High-frequency tracking page.
- Event detail page.
- Theme center.
- Market review.
- Stock detail page.
- Admin review page.

## Display Requirements

- Charts show source, update time, and data definition.
- AI modules show citations, confidence, risk notes, and generation state.
