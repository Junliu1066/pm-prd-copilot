# G

## AI Plan

## Model Routing

| Task | Model Level | Mode | Review |
|---|---|---|---|
| Entity extraction | Fast low-cost model | Async batch | Sample review |
| Event summary | Mid-quality model + retrieval | Async cached result | Review high-impact events |
| Stock analysis | High-quality model | Async generation | Review high-risk output |
| Content safety | Rules + classifier | Sync check | Manual review when triggered |
| Embedding | Dedicated embedding model | Async indexing | Recall evaluation |

## Required Output Shape

```json
{
  "facts": [],
  "inferences": [],
  "risks": [],
  "unknowns": [],
  "source_refs": [],
  "confidence_score": 0.0,
  "not_investment_advice": true
}
```

## Safety Constraints

- No buy or sell instruction.
- No target price.
- No position sizing advice.
- No guaranteed return.
- No unsupported material claim.
- No unauthorized full report redistribution.
