# H

## Open Questions

## Blocking

- Which data sources are authorized for MVP?
- Which model providers are approved for beta?
- What is the first allowlisted user group?
- What deployment target should be used for beta?

## Non-Blocking

- Exact Pro feature split.
- Email, SMS, or messaging-channel notification timing.
- Report export format.
- Team-space scope.
