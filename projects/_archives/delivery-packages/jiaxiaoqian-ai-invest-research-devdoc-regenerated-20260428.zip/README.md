# 价小前投研完整开发交付包说明

本交付包用于后续开发启动，包含产品、技术、原型、AI、开发治理和原始资料。

注意：用户侧产品是 AI 投研助手和投研工作台；内部多 agent / 管家、Skill/MCP、harness、Codex 任务包只属于开发治理，不进入用户侧产品表达。

## 目录

- `docs/`：PRD、开发文档、排期、验收、流程图、线框图、AI 模型选型、需求澄清。
- `prototype/`：低保真 HTML 原型。
- `source-assets/`：原始 PDF、PDF 文本抽取结果。
- `screenshots/`：PDF 页面截图和总览图，用于还原参考界面。
- `governance/`：项目级治理占位目录；后续可放内部开发配置、Skill/MCP 路由、harness 报告。

## 推荐阅读顺序

1. `docs/01_prd.md`
2. `docs/10_开发文档.md`
3. `docs/02_development_design.md`
4. `docs/05_function_flow.md`
5. `docs/06_prototype_wireframes.md`
6. `docs/07_ai_model_selection.md`
7. `docs/08_requirement_clarification.md`
8. `prototype/index.html`

## 开发启动重点

- 先确认数据源授权、模型供应商、部署方式和 MVP 范围。
- 开发文档必须按阶段写清楚“交付物、阶段实现效果、验收标准”，不能只列任务。
- Codex 开发前必须接入产品经理 Skill 框架：facts/assumptions/open questions、P0/P1/P2 门禁、Capability Enablement、Skill/MCP Discovery、内部多管家、效率部、随机审计、教师沉淀和 harness。
- 第一阶段优先实现工程底座、资料导入、事件中心、AI/RAG、内容安全和关注提醒。
- 所有 AI 输出必须保留来源、置信度、事实/推断/风险/待核验结构。
- Codex 半自动开发必须按 `10_开发文档.md` 的任务包、写入边界和人工确认门禁执行。
