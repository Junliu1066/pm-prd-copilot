# 价小前投研外部分发开发包说明

本包用于发给外部开发者、外包团队或合作方，只包含开发交付所需的产品范围、流程、原型、AI 方案、验收要求和脱敏开发方案。

## 目录

- `docs/01_prd.md`：产品 PRD。
- `docs/03_mvp_release_plan.md`：MVP 排期。
- `docs/04_tracking_and_acceptance.md`：埋点与验收。
- `docs/05_function_flow.md`：功能流程图。
- `docs/06_prototype_wireframes.md`：原型图 / 线框图。
- `docs/07_ai_model_selection.md`：AI 模型选型。
- `docs/08_requirement_clarification.md`：待确认问题。
- `docs/10_外部开发方案_脱敏版.md`：外部分发开发方案。
- `prototype/`：HTML 原型。

## 开发要求

- 不擅自增加 PRD 外功能。
- 每个阶段必须说明交付物、实现效果和验收标准。
- AI 输出必须保留来源、置信度、风险提示和降级方案。
- 涉及数据源、模型供应商、数据库结构、上线发布时必须先确认。
- 未完成测试或验证时必须说明原因和替代验证。
