const routeTitles = {
  dashboard: "Dashboard 页面",
  prompts: "Prompts 页面",
  "prompt-create": "创建 Prompt 页面",
  datasets: "Datasets 页面",
  models: "Models 页面",
  runs: "Runs 页面",
  evaluations: "Evaluations 页面",
  optimize: "Optimize 页面",
  compare: "Compare 页面",
  knowledge: "Knowledge 页面",
  settings: "Settings 页面"
};

const editKey = "prompt-workbench-v2-inline-edits";
const toast = document.querySelector("#toast");
const pageTitle = document.querySelector("#pageTitle");

function showToast(message) {
  toast.textContent = message || "操作已完成";
  toast.hidden = false;
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => {
    toast.hidden = true;
  }, 1600);
}

function showRoute(route) {
  const screen = document.querySelector(`[data-screen="${route}"]`);
  if (!screen) {
    showToast("该页面还未配置");
    return;
  }
  document.querySelectorAll(".screen").forEach((item) => item.classList.toggle("active", item === screen));
  document.querySelectorAll(".side-nav button").forEach((item) => item.classList.toggle("active", item.dataset.route === route));
  pageTitle.textContent = routeTitles[route] || "Prompt 优化工作台";
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function getEdits() {
  try {
    return JSON.parse(localStorage.getItem(editKey) || "{}");
  } catch {
    return {};
  }
}

function setEdits(edits) {
  localStorage.setItem(editKey, JSON.stringify(edits));
}

function editId(element) {
  if (element.dataset.editId) return element.dataset.editId;
  const all = Array.from(document.querySelectorAll(".editable, h1, h2, h3, p, td, th, li, small, strong"));
  const id = `edit-${all.indexOf(element)}`;
  element.dataset.editId = id;
  return id;
}

function applyEdits() {
  const edits = getEdits();
  document.querySelectorAll(".editable, h1, h2, h3, p, td, th, li, small, strong").forEach((element) => {
    if (element.closest("button") || element.closest("select") || element.closest("input") || !element.textContent.trim()) return;
    const id = editId(element);
    if (edits[id]) element.textContent = edits[id];
    element.dataset.inlineEditable = "true";
    element.title = "双击修改文本";
  });
}

function startEdit(element) {
  if (!element || element.closest("button") || element.closest("input") || element.closest("select")) return;
  const before = element.textContent;
  element.contentEditable = "true";
  element.classList.add("editing");
  element.focus();
  document.getSelection().selectAllChildren(element);

  function save() {
    element.contentEditable = "false";
    element.classList.remove("editing");
    const edits = getEdits();
    edits[editId(element)] = element.textContent.trim();
    setEdits(edits);
    cleanup();
    showToast("文本已保存到当前浏览器");
  }

  function cancel() {
    element.textContent = before;
    element.contentEditable = "false";
    element.classList.remove("editing");
    cleanup();
  }

  function onKeydown(event) {
    if (event.key === "Enter") {
      event.preventDefault();
      save();
    }
    if (event.key === "Escape") {
      event.preventDefault();
      cancel();
    }
  }

  function cleanup() {
    element.removeEventListener("blur", save);
    element.removeEventListener("keydown", onKeydown);
  }

  element.addEventListener("blur", save);
  element.addEventListener("keydown", onKeydown);
}

document.addEventListener("click", (event) => {
  const routeTarget = event.target.closest("[data-route]");
  if (routeTarget) {
    showRoute(routeTarget.dataset.route);
    return;
  }

  const tab = event.target.closest(".tabs button");
  if (tab) {
    tab.parentElement.querySelectorAll("button").forEach((item) => item.classList.remove("active"));
    tab.classList.add("active");
    showToast(`已切换到「${tab.textContent.trim()}」`);
    return;
  }

  const action = event.target.closest("[data-action]");
  if (action) {
    if (action.dataset.action === "select-row") {
      action.closest("tbody").querySelectorAll("tr").forEach((row) => row.classList.remove("selected"));
      action.closest("tr").classList.add("selected");
      showToast("已切换当前记录详情");
      return;
    }
    showToast(action.dataset.message || "操作已记录");
    return;
  }

  const button = event.target.closest("button");
  if (button) {
    const label = button.textContent.trim() || "按钮";
    showToast(`已点击「${label}」`);
  }
});

document.addEventListener("dblclick", (event) => {
  const target = event.target.closest("[data-inline-editable='true']");
  if (!target) return;
  event.preventDefault();
  startEdit(target);
});

applyEdits();
showRoute("datasets");
